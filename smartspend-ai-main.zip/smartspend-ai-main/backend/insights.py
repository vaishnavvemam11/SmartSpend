﻿from typing import List, Dict, Any
from datetime import datetime

CATEGORIES = ["Food", "Shopping", "Travel", "Rent", "Entertainment", "Education", "Other"]

def compute_financial_insights(income: float, expenses: list, goals: list = None) -> Dict[str, Any]:
    total_expenses = sum(float(e.amount) for e in expenses)
    savings = max(0.0, income - total_expenses) if income > 0 else 0.0
    savings_rate = round((savings / income) * 100.0, 1) if income > 0 else 0.0

    # Spending by category
    category_totals = {c: 0.0 for c in CATEGORIES}
    for e in expenses:
        cat = e.category if e.category in category_totals else "Other"
        category_totals[cat] += float(e.amount)

    category_percentages = {}
    for c, amt in category_totals.items():
        pct = round((amt / total_expenses * 100.0), 1) if total_expenses > 0 else 0.0
        category_percentages[c] = {
            "amount": round(amt, 2),
            "percentage": pct
        }

    # Identify highest category
    sorted_categories = sorted(category_totals.items(), key=lambda x: x[1], reverse=True)
    top_category, top_amount = sorted_categories[0] if sorted_categories and sorted_categories[0][1] > 0 else ("None", 0.0)
    top_pct = round((top_amount / total_expenses * 100.0), 1) if total_expenses > 0 else 0.0

    insights_list = []

    # 1. Top Spending Category Insight
    if top_amount > 0:
        insights_list.append({
            "title": "Highest Spending Category",
            "message": f"{top_category} is your highest spending category at ₹{top_amount:,.0f} ({top_pct}% of total expenses).",
            "type": "warning" if top_pct > 35 else "info",
            "metric": f"{top_pct}%"
        })

    # 2. Savings Rate Insight
    if savings_rate >= 40:
        insights_list.append({
            "title": "Exceptional Savings Rate",
            "message": f"Your savings rate is {savings_rate}%, well above the standard 20% financial independence benchmark. Keep compounding your surplus!",
            "type": "success",
            "metric": f"{savings_rate}%"
        })
    elif savings_rate >= 20:
        insights_list.append({
            "title": "Healthy Savings Habit",
            "message": f"Your savings rate is {savings_rate}%. You are successfully meeting the 50/30/20 guideline by putting away at least a fifth of your earnings.",
            "type": "success",
            "metric": f"{savings_rate}%"
        })
    elif savings_rate > 0:
        insights_list.append({
            "title": "Savings Opportunity",
            "message": f"Your current savings rate is {savings_rate}%. Consider identifying small recurring leaks in shopping or entertainment to reach the 20% target.",
            "type": "warning",
            "metric": f"{savings_rate}%"
        })
    else:
        insights_list.append({
            "title": "Budget Deficit Alert",
            "message": "Your monthly expenses currently equal or exceed your income. Prioritize auditing non-essential purchases immediately.",
            "type": "warning",
            "metric": "0%"
        })

    # 3. Discretionary vs Essential
    shopping_amt = category_totals.get("Shopping", 0.0)
    entertainment_amt = category_totals.get("Entertainment", 0.0)
    wants_total = shopping_amt + entertainment_amt
    wants_pct = round((wants_total / total_expenses * 100.0), 1) if total_expenses > 0 else 0.0

    if wants_pct > 30:
        insights_list.append({
            "title": "Lifestyle & Discretionary Spend",
            "message": f"Shopping and Entertainment account for {wants_pct}% of your expenses. Trimming non-essential orders by 10% can boost your monthly savings by ₹{wants_total * 0.1:,.0f}.",
            "type": "info",
            "metric": f"{wants_pct}%"
        })

    # 4. Goals Insight
    if goals:
        for g in goals:
            rem = max(0.0, float(g.target_amount) - float(g.current_amount))
            contrib = float(g.monthly_contribution)
            if rem > 0 and contrib > 0:
                months = round(rem / contrib, 1)
                insights_list.append({
                    "title": f"Goal Horizon: {g.name}",
                    "message": f"At ₹{contrib:,.0f}/month, you are on track to achieve your {g.name} in approximately {months:g} months (₹{rem:,.0f} remaining).",
                    "type": "info",
                    "metric": f"{months:g} mo"
                })
                break

    # Primary headline insight for dashboard banner
    if top_amount > 0:
        top_banner_insight = {
            "title": "Smart Spending Insight",
            "message": f"Your {top_category.lower()} expenses account for {top_pct}% of total spending. Consider reviewing discretionary orders to maintain your {savings_rate}% savings rate.",
            "type": "info",
            "metric": f"{savings_rate}% Savings"
        }
    else:
        top_banner_insight = {
            "title": "Welcome to SmartSpend AI",
            "message": "Start adding your daily expenses to see automated AI insights and personalized budget advice.",
            "type": "info",
            "metric": "100% Ready"
        }

    return {
        "total_expenses": round(total_expenses, 2),
        "current_savings": round(savings, 2),
        "savings_rate": savings_rate,
        "category_overview": category_percentages,
        "insights": insights_list,
        "top_insight": top_banner_insight
    }
