﻿import os
import pickle
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np

CATEGORIES = ["Food", "Shopping", "Travel", "Rent", "Entertainment", "Education", "Other"]
cat_to_id = {c: i for i, c in enumerate(CATEGORIES)}
id_to_cat = {i: c for i, c in enumerate(CATEGORIES)}

TRAINING_DATA = [
    # Food
    ("swiggy order", "Food"), ("swiggy delivery", "Food"), ("zomato food delivery", "Food"),
    ("zomato biryani", "Food"), ("mcdonalds burger meal", "Food"), ("starbucks iced latte", "Food"),
    ("grocery store supermarket", "Food"), ("blinkit grocery order", "Food"), ("zepto 10 min grocery", "Food"),
    ("bigbasket weekly vegetables", "Food"), ("dinner at restaurant", "Food"), ("lunch buffet dining", "Food"),
    ("dominos pizza delivery", "Food"), ("subway sandwich meal", "Food"), ("kfc chicken bucket", "Food"),
    ("local bakery bread and cake", "Food"), ("coffee and tea cafe bistro", "Food"), ("fresh fruits and vegetables", "Food"),
    ("chai point snack", "Food"), ("haldirams sweets and snacks", "Food"), ("swiggy instamart", "Food"),

    # Shopping
    ("amazon purchase", "Shopping"), ("amazon order electronics", "Shopping"), ("flipkart big billion sale", "Shopping"),
    ("flipkart order parcel", "Shopping"), ("myntra clothes shopping", "Shopping"), ("zara denim jacket jeans", "Shopping"),
    ("nike running shoes sports", "Shopping"), ("shopping mall apparel", "Shopping"), ("h&m cotton t-shirt", "Shopping"),
    ("electronics gadgets wireless headphones", "Shopping"), ("sunglasses lenskart eyewear", "Shopping"),
    ("cosmetics makeup nykaa store", "Shopping"), ("online shopping purchase", "Shopping"), ("retail fashion store", "Shopping"),
    ("ikea home decor furniture", "Shopping"), ("apple store macbook accessories", "Shopping"), ("croma appliance", "Shopping"),

    # Travel
    ("uber ride", "Travel"), ("uber trip downtown", "Travel"), ("ola cab booking", "Travel"),
    ("ola auto ride", "Travel"), ("rapido bike taxi trip", "Travel"), ("metro smart card recharge", "Travel"),
    ("petrol fuel gas pump", "Travel"), ("diesel refuel car", "Travel"), ("flight ticket booking indigo air", "Travel"),
    ("train reservation ticket irctc", "Travel"), ("intercity express bus ticket", "Travel"), ("highway toll tax fastag recharge", "Travel"),
    ("airport taxi cab ride", "Travel"), ("city parking fee ticket", "Travel"), ("ev charging station electricity", "Travel"),

    # Rent
    ("apartment rent payment", "Rent"), ("house rent monthly lease", "Rent"), ("monthly flat lease payment", "Rent"),
    ("room rent transfer to landlord", "Rent"), ("society building maintenance fee", "Rent"), ("pg accommodation rent", "Rent"),
    ("flat security deposit installment", "Rent"), ("studio apartment monthly rent", "Rent"), ("office cabin coworking rent", "Rent"),

    # Entertainment
    ("netflix monthly subscription", "Entertainment"), ("spotify premium music family", "Entertainment"),
    ("amazon prime video annual membership", "Entertainment"), ("bookmyshow cinema movie tickets", "Entertainment"),
    ("pvr inox cinemas popcorn movie", "Entertainment"), ("youtube premium music student", "Entertainment"),
    ("playstation 5 video game steam", "Entertainment"), ("disney plus hotstar vip subscription", "Entertainment"),
    ("live music concert passes festival", "Entertainment"), ("gaming cafe vr arcade", "Entertainment"),
    ("standup comedy show entry ticket", "Entertainment"), ("water theme park entry pass", "Entertainment"),

    # Education
    ("udemy course python data science", "Education"), ("coursera specialization certificate fee", "Education"),
    ("college semester tuition fee payment", "Education"), ("university examination registration fee", "Education"),
    ("school quarterly fees", "Education"), ("textbooks and reference study guides", "Education"),
    ("certification exam aws cloud fee", "Education"), ("coaching institute entrance fees", "Education"),
    ("edx computer science degree course", "Education"), ("library annual reading membership", "Education"),
    ("online fullstack coding bootcamp", "Education"), ("ielts exam preparation registration", "Education"),

    # Other
    ("apollo pharmacy medicines prescription", "Other"), ("doctor consultation clinic specialist", "Other"),
    ("hospital medical health checkup diagnostic", "Other"), ("gym monthly membership fitness crossfit", "Other"),
    ("electricity power utility bill bescom", "Other"), ("water supply municipal bill", "Other"),
    ("wifi broadband internet act fiber bill", "Other"), ("laundry dry cleaning service", "Other"),
    ("mobile prepaid recharge jio airtel vi", "Other"), ("car auto insurance annual renewal", "Other"),
    ("bank service charges and penalty fees", "Other"), ("haircut salon spa grooming", "Other")
]

class ExpenseClassifier(nn.Module):
    """
    Lightweight, explainable PyTorch MLP classifier for transaction text categorization.
    Architecture:
    Input (TF-IDF subword/word features) -> Linear -> BatchNorm -> ReLU -> Dropout -> Linear -> ReLU -> Linear -> Logits
    """
    def __init__(self, vocab_size: int, hidden_dim: int = 64, num_classes: int = 7):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(vocab_size, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(hidden_dim, 32),
            nn.ReLU(),
            nn.Linear(32, num_classes)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)

class PyTorchExpenseModel:
    def __init__(self):
        self.model = None
        self.vectorizer = None
        self.is_ready = False
        self._init_and_train()

    def _init_and_train(self):
        texts = [item[0] for item in TRAINING_DATA]
        labels = [cat_to_id[item[1]] for item in TRAINING_DATA]

        self.vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=1, sublinear_tf=True)
        X = self.vectorizer.fit_transform(texts).toarray()
        y = np.array(labels)

        X_tensor = torch.tensor(X, dtype=torch.float32)
        y_tensor = torch.tensor(y, dtype=torch.long)

        vocab_size = X.shape[1]
        self.model = ExpenseClassifier(vocab_size=vocab_size, hidden_dim=64, num_classes=len(CATEGORIES))
        
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(self.model.parameters(), lr=0.015, weight_decay=1e-4)

        self.model.train()
        for epoch in range(70):
            optimizer.zero_grad()
            outputs = self.model(X_tensor)
            loss = criterion(outputs, y_tensor)
            loss.backward()
            optimizer.step()

        self.model.eval()
        self.is_ready = True

    def predict(self, description: str) -> dict:
        if not description or not description.strip():
            return {
                "description": description,
                "category": "Other",
                "confidence": 0.5,
                "confidence_percentage": "50%"
            }

        cleaned = description.strip().lower()
        features = self.vectorizer.transform([cleaned]).toarray()
        
        # If no vocabulary matches were found, fallback smoothly
        if features.sum() == 0:
            return {
                "description": description,
                "category": "Other",
                "confidence": 0.45,
                "confidence_percentage": "45%"
            }

        feat_tensor = torch.tensor(features, dtype=torch.float32)
        with torch.no_grad():
            logits = self.model(feat_tensor)
            probs = torch.softmax(logits, dim=1).squeeze().cpu().numpy()
            pred_idx = int(np.argmax(probs))
            pred_cat = id_to_cat[pred_idx]
            conf = float(probs[pred_idx])

        # Minimum confidence clamp for display quality
        display_conf = max(0.60, min(0.99, conf))

        return {
            "description": description,
            "category": pred_cat,
            "confidence": round(display_conf, 2),
            "confidence_percentage": f"{int(round(display_conf * 100))}%"
        }

# Global singleton
categorizer = PyTorchExpenseModel()

def predict_transaction_category(description: str) -> dict:
    return categorizer.predict(description)
