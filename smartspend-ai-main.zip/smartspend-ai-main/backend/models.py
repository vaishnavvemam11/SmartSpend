from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from database import Base

class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), default='Demo User')
    email = Column(String(100), default='user@smartspend.ai')
    created_at = Column(DateTime, default=datetime.utcnow)

    incomes = relationship('Income', back_populates='user', cascade='all, delete-orphan')
    expenses = relationship('Expense', back_populates='user', cascade='all, delete-orphan')
    goals = relationship('Goal', back_populates='user', cascade='all, delete-orphan')
    chat_messages = relationship('ChatMessage', back_populates='user', cascade='all, delete-orphan')

class Income(Base):
    __tablename__ = 'incomes'

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), default=1)
    amount = Column(Float, nullable=False, default=50000.0)
    source = Column(String(100), default='Primary Salary')
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship('User', back_populates='incomes')

class Expense(Base):
    __tablename__ = 'expenses'

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), default=1)
    name = Column(String(200), nullable=False)
    amount = Column(Float, nullable=False)
    category = Column(String(50), nullable=False)
    date = Column(String(10), nullable=False)  # YYYY-MM-DD
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship('User', back_populates='expenses')

class Goal(Base):
    __tablename__ = 'goals'

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), default=1)
    name = Column(String(200), nullable=False)
    target_amount = Column(Float, nullable=False)
    current_amount = Column(Float, default=0.0)
    monthly_contribution = Column(Float, default=1000.0)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship('User', back_populates='goals')

class ChatMessage(Base):
    __tablename__ = 'chat_messages'

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), default=1)
    role = Column(String(20), nullable=False)  # 'user' or 'assistant'
    content = Column(Text, nullable=False)
    sources = Column(String(200), nullable=True)  # comma-separated source files
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship('User', back_populates='chat_messages')
