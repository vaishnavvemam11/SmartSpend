from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

# --- Expenses ---
class ExpenseBase(BaseModel):
    name: str = Field(..., example='Swiggy order')
    amount: float = Field(..., gt=0, example=450.0)
    category: str = Field(..., example='Food')
    date: str = Field(..., example='2026-09-09')

class ExpenseCreate(ExpenseBase):
    pass

class ExpenseUpdate(BaseModel):
    name: Optional[str] = None
    amount: Optional[float] = None
    category: Optional[str] = None
    date: Optional[str] = None

class ExpenseResponse(ExpenseBase):
    id: int
    user_id: int
    created_at: datetime

    class Config:
        from_attributes = True

# --- Income ---
class IncomeBase(BaseModel):
    amount: float = Field(..., gt=0, example=50000.0)
    source: Optional[str] = 'Primary Salary'

class IncomeCreate(IncomeBase):
    pass

class IncomeResponse(IncomeBase):
    id: int
    user_id: int
    created_at: datetime

    class Config:
        from_attributes = True

# --- Savings Goals ---
class GoalBase(BaseModel):
    name: str = Field(..., example='New Laptop')
    target_amount: float = Field(..., gt=0, example=80000.0)
    current_amount: float = Field(default=0.0, ge=0, example=30000.0)
    monthly_contribution: float = Field(default=1000.0, gt=0, example=10000.0)

class GoalCreate(GoalBase):
    pass

class GoalUpdate(BaseModel):
    name: Optional[str] = None
    target_amount: Optional[float] = None
    current_amount: Optional[float] = None
    monthly_contribution: Optional[float] = None

class GoalContribute(BaseModel):
    amount: float = Field(..., gt=0, example=5000.0)

class GoalResponse(GoalBase):
    id: int
    user_id: int
    progress_percentage: float = 0.0
    amount_remaining: float = 0.0
    estimated_months: float = 0.0
    created_at: datetime

    class Config:
        from_attributes = True

# --- AI Categorization ---
class CategorizeRequest(BaseModel):
    description: str = Field(..., example='Uber ride')

class CategorizeResponse(BaseModel):
    description: str
    category: str
    confidence: float
    confidence_percentage: str

# --- AI Insights ---
class InsightItem(BaseModel):
    title: str
    message: str
    type: str = 'info'  # 'success', 'warning', 'info'
    metric: Optional[str] = None

# --- AI Chat ---
class ChatRequest(BaseModel):
    message: str = Field(..., example='Where am I spending the most?')

class ChatResponse(BaseModel):
    reply: str
    sources: Optional[List[str]] = None
    context_type: str = 'financial_data'  # 'financial_data', 'rag_knowledge', 'general'

class ChatMessageResponse(BaseModel):
    id: int
    role: str
    content: str
    sources: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True

# --- Dashboard ---
class CategorySpend(BaseModel):
    category: str
    amount: float
    percentage: float

class MonthlyTrend(BaseModel):
    month: str
    income: float
    expenses: float
    savings: float

class DashboardResponse(BaseModel):
    monthly_income: float
    total_expenses: float
    current_savings: float
    savings_rate: float
    spending_overview: List[CategorySpend]
    monthly_overview: List[MonthlyTrend]
    top_insight: InsightItem
    recent_expenses: List[ExpenseResponse]
