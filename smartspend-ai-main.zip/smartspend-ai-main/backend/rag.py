import os
import faiss
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize

class FinancialRAG:
    """
    Lightweight, explainable RAG engine using FAISS IndexFlatIP (Cosine Similarity).
    Indexed over financial education documents in knowledge_base/.
    """
    def __init__(self, kb_dir: str = None):
        if kb_dir is None:
            kb_env = os.environ.get("KB_DIR")
            if kb_env and os.path.exists(kb_env):
                kb_dir = kb_env
            else:
                base_dir = os.path.dirname(os.path.abspath(__file__))
                cand1 = os.path.join(os.path.dirname(base_dir), "knowledge_base")
                cand2 = os.path.join(base_dir, "knowledge_base")
                cand3 = os.path.join(os.getcwd(), "knowledge_base")
                if os.path.exists(cand1):
                    kb_dir = cand1
                elif os.path.exists(cand2):
                    kb_dir = cand2
                else:
                    kb_dir = cand3
        self.kb_dir = kb_dir
        self.chunks = []
        self.metadata = []
        self.vectorizer = None
        self.index = None
        self.is_ready = False
        self._build_index()

    def _build_index(self):
        if not os.path.exists(self.kb_dir):
            return

        files = [
            "budgeting.txt",
            "saving.txt",
            "emergency_fund.txt",
            "compound_interest.txt",
            "debt_management.txt"
        ]

        raw_chunks = []
        raw_meta = []

        for fname in files:
            fpath = os.path.join(self.kb_dir, fname)
            if not os.path.exists(fpath):
                continue
            with open(fpath, "r", encoding="utf-8") as f:
                content = f.read()

            sections = content.split("## ")
            doc_title = sections[0].replace("# ", "").strip()
            
            for sec in sections[1:]:
                lines = sec.strip().split("\n")
                heading = lines[0].strip()
                body = "\n".join(lines[1:]).strip()
                full_chunk = f"Topic: {heading}\nContext: {body}"
                raw_chunks.append(full_chunk)
                raw_meta.append({
                    "file": fname,
                    "heading": heading,
                    "doc_title": doc_title,
                    "body": body
                })

        if not raw_chunks:
            return

        self.chunks = raw_chunks
        self.metadata = raw_meta

        self.vectorizer = TfidfVectorizer(
            ngram_range=(1, 2),
            stop_words="english",
            max_features=512,
            sublinear_tf=True
        )
        X = self.vectorizer.fit_transform(self.chunks).toarray()
        X_norm = normalize(X, norm="l2", axis=1).astype(np.float32)

        dimension = X_norm.shape[1]
        self.index = faiss.IndexFlatIP(dimension)
        self.index.add(X_norm)
        self.is_ready = True

    def query(self, question: str, top_k: int = 2) -> dict:
        if not self.is_ready or not question.strip():
            return {"found": False, "answer": "", "sources": []}

        q_vec = self.vectorizer.transform([question.lower()]).toarray()
        if q_vec.sum() == 0:
            return {"found": False, "answer": "", "sources": []}

        q_norm = normalize(q_vec, norm="l2", axis=1).astype(np.float32)
        distances, indices = self.index.search(q_norm, top_k)

        top_score = float(distances[0][0])
        if top_score < 0.10:
            return {"found": False, "answer": "", "sources": []}

        retrieved_items = []
        sources = set()

        for idx, score in zip(indices[0], distances[0]):
            if 0 <= idx < len(self.metadata):
                item = self.metadata[idx]
                sources.add(item["file"])
                retrieved_items.append({
                    "score": float(score),
                    "heading": item["heading"],
                    "body": item["body"],
                    "file": item["file"]
                })

        primary = retrieved_items[0]
        answer_parts = [
            f"### 💡 {primary['heading']}",
            f"{primary['body']}"
        ]

        if len(retrieved_items) > 1 and retrieved_items[1]["score"] > 0.18:
            secondary = retrieved_items[1]
            if secondary["heading"] != primary["heading"]:
                answer_parts.append(f"\n**Additional Concept ({secondary['heading']}):**\n{secondary['body']}")

        return {
            "found": True,
            "answer": "\n\n".join(answer_parts),
            "sources": list(sources),
            "top_score": top_score
        }

rag_engine = FinancialRAG()

def query_financial_rag(question: str) -> dict:
    return rag_engine.query(question)
