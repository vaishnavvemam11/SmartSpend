import os
import sys

# Ensure backend directory is in sys.path regardless of execution working directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from fastapi import FastAPI, Depends, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta

from database import engine, get_db, Base
import models
import schemas
import ai
import rag
import insights

# Initialize database tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="SmartSpend AI API",
    description="Intelligent personal finance backend with PyTorch categorization and FAISS RAG",
    version="1.0.0"
)

# Enable CORS for React frontend (Vite defaults to port 5173, production port 80/3000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Helper: Ensure a default user exists
def get_or_create_default_user(db: Session) -> models.User:
    user = db.query(models.User).filter(models.User.id == 1).first()
    if not user:
        user = models.User(id=1, name="Aditya", email="user@smartspend.ai")
        db.add(user)
        # Default income: ₹50,000
        income = models.Income(user_id=1, amount=50000.0, source="Primary Salary")
        db.add(income)
        db.commit()
        db.refresh(user)
    return user

# Helper: compute goal progress metrics
def format_goal_response(goal: models.Goal) -> schemas.GoalResponse:
    target = float(goal.target_amount)
    current = float(goal.current_amount)
    contrib = float(goal.monthly_contribution)

    progress = round(min(100.0, (current / target * 100.0)), 1) if target > 0 else 0.0
    remaining = max(0.0, target - current)
    estimated_months = round(remaining / contrib, 1) if contrib > 0 else 0.0

    return schemas.GoalResponse(
        id=goal.id,
        user_id=goal.user_id,
        name=goal.name,
        target_amount=target,
        current_amount=current,
        monthly_contribution=contrib,
        progress_percentage=progress,
        amount_remaining=remaining,
        estimated_months=estimated_months,
        created_at=goal.created_at
    )

# --- Health Check ---
@app.get("/health", tags=["System"])
def health_check():
    return {
        "status": "healthy",
        "service": "SmartSpend AI API",
        "pytorch_model_ready": ai.categorizer.is_ready,
        "rag_index_ready": rag.rag_engine.is_ready,
        "version": "1.0.0"
    }

# --- Income Endpoints ---
@app.get("/income", response_model=schemas.IncomeResponse, tags=["Income"])
def get_income(db: Session = Depends(get_db)):
    user = get_or_create_default_user(db)
    income = db.query(models.Income).filter(models.Income.user_id == user.id).order_by(models.Income.id.desc()).first()
    if not income:
        income = models.Income(user_id=user.id, amount=50000.0, source="Primary Salary")
        db.add(income)
        db.commit()
        db.refresh(income)
    return income

@app.post("/income", response_model=schemas.IncomeResponse, tags=["Income"])
def update_income(data: schemas.IncomeCreate, db: Session = Depends(get_db)):
    user = get_or_create_default_user(db)
    income = db.query(models.Income).filter(models.Income.user_id == user.id).order_by(models.Income.id.desc()).first()
    if income:
        income.amount = data.amount
        if data.source:
            income.source = data.source
    else:
        income = models.Income(user_id=user.id, amount=data.amount, source=data.source or "Primary Salary")
        db.add(income)
    db.commit()
    db.refresh(income)
    return income

# --- Expenses Endpoints ---
@app.get("/expenses", response_model=List[schemas.ExpenseResponse], tags=["Expenses"])
def get_expenses(category: Optional[str] = None, db: Session = Depends(get_db)):
    user = get_or_create_default_user(db)
    query = db.query(models.Expense).filter(models.Expense.user_id == user.id)
    if category and category != "All":
        query = query.filter(models.Expense.category == category)
    return query.order_by(models.Expense.date.desc(), models.Expense.id.desc()).all()

@app.post("/expenses", response_model=schemas.ExpenseResponse, tags=["Expenses"])
def create_expense(expense_in: schemas.ExpenseCreate, db: Session = Depends(get_db)):
    user = get_or_create_default_user(db)
    category = expense_in.category

    # If category is empty or 'Auto', predict with PyTorch model
    if not category or category in ["Auto", "Uncategorized"]:
        pred = ai.predict_transaction_category(expense_in.name)
        category = pred["category"]

    expense = models.Expense(
        user_id=user.id,
        name=expense_in.name,
        amount=expense_in.amount,
        category=category,
        date=expense_in.date
    )
    db.add(expense)
    db.commit()
    db.refresh(expense)
    return expense

@app.put("/expenses/{id}", response_model=schemas.ExpenseResponse, tags=["Expenses"])
def update_expense(id: int, update_data: schemas.ExpenseUpdate, db: Session = Depends(get_db)):
    user = get_or_create_default_user(db)
    expense = db.query(models.Expense).filter(models.Expense.id == id, models.Expense.user_id == user.id).first()
    if not expense:
        raise HTTPException(status_code=404, detail="Expense not found")

    if update_data.name is not None:
        expense.name = update_data.name
    if update_data.amount is not None:
        expense.amount = update_data.amount
    if update_data.category is not None:
        expense.category = update_data.category
    if update_data.date is not None:
        expense.date = update_data.date

    db.commit()
    db.refresh(expense)
    return expense

@app.delete("/expenses/{id}", tags=["Expenses"])
def delete_expense(id: int, db: Session = Depends(get_db)):
    user = get_or_create_default_user(db)
    expense = db.query(models.Expense).filter(models.Expense.id == id, models.Expense.user_id == user.id).first()
    if not expense:
        raise HTTPException(status_code=404, detail="Expense not found")
    db.delete(expense)
    db.commit()
    return {"message": "Expense deleted successfully", "id": id}

# --- Savings Goals Endpoints ---
@app.get("/goals", response_model=List[schemas.GoalResponse], tags=["Goals"])
def get_goals(db: Session = Depends(get_db)):
    user = get_or_create_default_user(db)
    goals = db.query(models.Goal).filter(models.Goal.user_id == user.id).all()
    return [format_goal_response(g) for g in goals]

@app.post("/goals", response_model=schemas.GoalResponse, tags=["Goals"])
def create_goal(goal_in: schemas.GoalCreate, db: Session = Depends(get_db)):
    user = get_or_create_default_user(db)
    goal = models.Goal(
        user_id=user.id,
        name=goal_in.name,
        target_amount=goal_in.target_amount,
        current_amount=goal_in.current_amount,
        monthly_contribution=goal_in.monthly_contribution
    )
    db.add(goal)
    db.commit()
    db.refresh(goal)
    return format_goal_response(goal)

@app.put("/goals/{id}", response_model=schemas.GoalResponse, tags=["Goals"])
def update_goal(id: int, goal_in: schemas.GoalUpdate, db: Session = Depends(get_db)):
    user = get_or_create_default_user(db)
    goal = db.query(models.Goal).filter(models.Goal.id == id, models.Goal.user_id == user.id).first()
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")

    if goal_in.name is not None:
        goal.name = goal_in.name
    if goal_in.target_amount is not None:
        goal.target_amount = goal_in.target_amount
    if goal_in.current_amount is not None:
        goal.current_amount = goal_in.current_amount
    if goal_in.monthly_contribution is not None:
        goal.monthly_contribution = goal_in.monthly_contribution

    db.commit()
    db.refresh(goal)
    return format_goal_response(goal)

@app.post("/goals/{id}/contribute", response_model=schemas.GoalResponse, tags=["Goals"])
def contribute_to_goal(id: int, data: schemas.GoalContribute, db: Session = Depends(get_db)):
    user = get_or_create_default_user(db)
    goal = db.query(models.Goal).filter(models.Goal.id == id, models.Goal.user_id == user.id).first()
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")

    goal.current_amount += data.amount
    db.commit()
    db.refresh(goal)
    return format_goal_response(goal)

@app.delete("/goals/{id}", tags=["Goals"])
def delete_goal(id: int, db: Session = Depends(get_db)):
    user = get_or_create_default_user(db)
    goal = db.query(models.Goal).filter(models.Goal.id == id, models.Goal.user_id == user.id).first()
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")
    db.delete(goal)
    db.commit()
    return {"message": "Goal deleted successfully", "id": id}

# --- AI Categorization Endpoint ---
@app.post("/ai/categorize", response_model=schemas.CategorizeResponse, tags=["AI"])
def categorize_expense(req: schemas.CategorizeRequest):
    return ai.predict_transaction_category(req.description)

# --- AI Insights Endpoint ---
@app.get("/ai/insights", tags=["AI"])
def get_ai_insights(db: Session = Depends(get_db)):
    user = get_or_create_default_user(db)
    income_obj = db.query(models.Income).filter(models.Income.user_id == user.id).order_by(models.Income.id.desc()).first()
    monthly_income = float(income_obj.amount) if income_obj else 50000.0

    expenses = db.query(models.Expense).filter(models.Expense.user_id == user.id).all()
    goals = db.query(models.Goal).filter(models.Goal.user_id == user.id).all()

    calc = insights.compute_financial_insights(monthly_income, expenses, goals)
    return calc["insights"]

# --- Dashboard Endpoint ---
@app.get("/dashboard", response_model=schemas.DashboardResponse, tags=["Dashboard"])
def get_dashboard(db: Session = Depends(get_db)):
    user = get_or_create_default_user(db)
    income_obj = db.query(models.Income).filter(models.Income.user_id == user.id).order_by(models.Income.id.desc()).first()
    monthly_income = float(income_obj.amount) if income_obj else 50000.0

    expenses = db.query(models.Expense).filter(models.Expense.user_id == user.id).all()
    goals = db.query(models.Goal).filter(models.Goal.user_id == user.id).all()

    calc = insights.compute_financial_insights(monthly_income, expenses, goals)

    # Spending overview array for Recharts Pie/Donut
    spending_overview = [
        schemas.CategorySpend(
            category=cat,
            amount=data["amount"],
            percentage=data["percentage"]
        )
        for cat, data in calc["category_overview"].items()
        if data["amount"] > 0
    ]

    # If no expenses yet, provide empty category placeholders for UI display
    if not spending_overview:
        spending_overview = [
            schemas.CategorySpend(category=cat, amount=0.0, percentage=0.0)
            for cat in insights.CATEGORIES
        ]

    # Monthly Overview Bar Chart data: past 3 months + current month
    # Group expenses by month (YYYY-MM)
    monthly_map = {}
    for e in expenses:
        m = e.date[:7] if len(e.date) >= 7 else datetime.utcnow().strftime("%Y-%m")
        monthly_map[m] = monthly_map.get(m, 0.0) + float(e.amount)

    current_month_str = datetime.utcnow().strftime("%Y-%m")
    if current_month_str not in monthly_map:
        monthly_map[current_month_str] = calc["total_expenses"]

    sorted_months = sorted(monthly_map.keys())[-4:]
    monthly_overview = []
    for m in sorted_months:
        exp_m = monthly_map.get(m, 0.0)
        sav_m = max(0.0, monthly_income - exp_m)
        monthly_overview.append(
            schemas.MonthlyTrend(
                month=m,
                income=monthly_income,
                expenses=round(exp_m, 2),
                savings=round(sav_m, 2)
            )
        )

    recent_expenses = db.query(models.Expense).filter(
        models.Expense.user_id == user.id
    ).order_by(models.Expense.date.desc(), models.Expense.id.desc()).limit(5).all()

    return schemas.DashboardResponse(
        monthly_income=monthly_income,
        total_expenses=calc["total_expenses"],
        current_savings=calc["current_savings"],
        savings_rate=calc["savings_rate"],
        spending_overview=spending_overview,
        monthly_overview=monthly_overview,
        top_insight=schemas.InsightItem(**calc["top_insight"]),
        recent_expenses=recent_expenses
    )

# --- AI Chat Advisor with RAG and User Context ---
@app.post("/ai/chat", response_model=schemas.ChatResponse, tags=["AI"])
def chat_with_ai(req: schemas.ChatRequest, db: Session = Depends(get_db)):
    user = get_or_create_default_user(db)
    user_msg = req.message.strip()
    msg_lower = user_msg.lower()

    # Retrieve live financial stats
    income_obj = db.query(models.Income).filter(models.Income.user_id == user.id).order_by(models.Income.id.desc()).first()
    monthly_income = float(income_obj.amount) if income_obj else 50000.0
    expenses = db.query(models.Expense).filter(models.Expense.user_id == user.id).all()
    goals = db.query(models.Goal).filter(models.Goal.user_id == user.id).all()

    calc = insights.compute_financial_insights(monthly_income, expenses, goals)
    total_expenses = calc["total_expenses"]
    savings = calc["current_savings"]
    savings_rate = calc["savings_rate"]

    # Category breakdown details
    cat_summary = [f"{c}: ₹{d['amount']:,.0f} ({d['percentage']}%)" for c, d in calc["category_overview"].items() if d["amount"] > 0]
    sorted_cats = sorted(calc["category_overview"].items(), key=lambda x: x[1]["amount"], reverse=True)
    top_cat = sorted_cats[0][0] if sorted_cats and sorted_cats[0][1]["amount"] > 0 else "None"
    top_amt = sorted_cats[0][1]["amount"] if sorted_cats else 0.0

    # 1. Check if user is asking personal financial data questions
    is_spending_query = any(k in msg_lower for k in ["where", "spending most", "highest spend", "most spend", "category"])
    is_reduction_query = any(k in msg_lower for k in ["reduce", "cut down", "lower", "save more", "decrease expenses"])
    is_savings_query = any(k in msg_lower for k in ["how much can i save", "save this month", "my savings", "savings rate"])
    is_goal_query = any(k in msg_lower for k in ["reach my goal", "savings goal", "laptop", "target goal", "how to reach"])

    if is_spending_query and total_expenses > 0:
        reply = (
            f"📊 **Spending Analysis**:\n\n"
            f"You are spending the most on **{top_cat}**, totaling **₹{top_amt:,.0f}** "
            f"({calc['category_overview'][top_cat]['percentage']}% of your total ₹{total_expenses:,.0f} expenses).\n\n"
            f"**Full Category Breakdown:**\n" +
            "\n".join([f"- {s}" for s in cat_summary]) + "\n\n"
            f"💡 *Actionable Tip*: Since {top_cat} makes up the largest share of your budget, setting a weekly cap on {top_cat.lower()} can produce the quickest savings boost."
        )
        context_type = "financial_data"
        sources = []

    elif is_reduction_query:
        shopping = calc["category_overview"].get("Shopping", {}).get("amount", 0.0)
        food = calc["category_overview"].get("Food", {}).get("amount", 0.0)
        reply = (
            f"✂️ **Expense Reduction Recommendations**:\n\n"
            f"1. **Discretionary Purchases**: You spent ₹{shopping:,.0f} on Shopping and ₹{food:,.0f} on Food dining/orders. "
            f"Targeting a 15% reduction in these categories can unlock an extra **₹{(shopping + food) * 0.15:,.0f}** in monthly cash flow.\n"
            f"2. **The 48-Hour Rule**: Wait 48 hours before making non-essential purchases above ₹1,000 to eliminate impulse buying.\n"
            f"3. **Subscription Audit**: Review entertainment or streaming charges to cancel inactive services.\n\n"
            f"Your current monthly savings is **₹{savings:,.0f}** ({savings_rate}%). Reducing expenses will accelerate your goals!"
        )
        context_type = "financial_data"
        sources = []

    elif is_savings_query:
        reply = (
            f"💰 **Monthly Savings Projection**:\n\n"
            f"- **Monthly Income**: ₹{monthly_income:,.0f}\n"
            f"- **Total Tracked Expenses**: ₹{total_expenses:,.0f}\n"
            f"- **Current Net Savings**: **₹{savings:,.0f}**\n"
            f"- **Savings Rate**: **{savings_rate}%**\n\n"
            f"{'🎉 Great job! You are exceeding the 20% savings rule.' if savings_rate >= 20 else '⚠️ Your savings rate is below the 20% benchmark. Look into trimming variable expenses.'}"
        )
        context_type = "financial_data"
        sources = []

    elif is_goal_query and goals:
        primary_goal = goals[0]
        rem = max(0.0, float(primary_goal.target_amount) - float(primary_goal.current_amount))
        contrib = float(primary_goal.monthly_contribution)
        months = round(rem / contrib, 1) if contrib > 0 else 0.0
        reply = (
            f"🎯 **Savings Goal Strategy ({primary_goal.name})**:\n\n"
            f"- **Target**: ₹{primary_goal.target_amount:,.0f}\n"
            f"- **Current Saved**: ₹{primary_goal.current_amount:,.0f} ({round(primary_goal.current_amount / primary_goal.target_amount * 100, 1)}%)\n"
            f"- **Remaining Needed**: ₹{rem:,.0f}\n"
            f"- **Monthly Contribution**: ₹{contrib:,.0f}\n"
            f"- **Estimated Time to Completion**: **{months:g} months**\n\n"
            f"💡 *Acceleration Strategy*: If you redirect ₹2,000 from your monthly savings (currently ₹{savings:,.0f}), you will finish **{max(1, int(round(months * 0.2)))} month(s) faster**!"
        )
        context_type = "financial_data"
        sources = []

    else:
        # 2. Check Financial RAG for educational topics
        rag_res = rag.query_financial_rag(user_msg)
        if rag_res["found"]:
            reply = rag_res["answer"]
            sources = rag_res["sources"]
            context_type = "rag_knowledge"
        else:
            # Fallback general friendly assistant response
            reply = (
                f"Hello! I am your **SmartSpend AI** financial assistant. 🤖\n\n"
                f"I can help you analyze your personal spending habits or explain essential financial concepts:\n\n"
                f"- **Your Finances**: Ask *'Where am I spending the most?'*, *'How can I reduce expenses?'*, or *'How much can I save?'*\n"
                f"- **Financial Education**: Ask *'What is an emergency fund?'*, *'Explain the 50/30/20 rule'*, or *'How does compound interest work?'*\n\n"
                f"Currently, your monthly income is **₹{monthly_income:,.0f}**, total expenses are **₹{total_expenses:,.0f}**, and your savings rate is **{savings_rate}%**."
            )
            context_type = "general"
            sources = []

    # Save to ChatMessage table
    chat_record = models.ChatMessage(
        user_id=user.id,
        role="user",
        content=user_msg
    )
    db.add(chat_record)
    asst_record = models.ChatMessage(
        user_id=user.id,
        role="assistant",
        content=reply,
        sources=",".join(sources) if sources else None
    )
    db.add(asst_record)
    db.commit()

    return schemas.ChatResponse(
        reply=reply,
        sources=sources,
        context_type=context_type
    )

@app.get("/ai/chat/history", response_model=List[schemas.ChatMessageResponse], tags=["AI"])
def get_chat_history(db: Session = Depends(get_db)):
    user = get_or_create_default_user(db)
    return db.query(models.ChatMessage).filter(
        models.ChatMessage.user_id == user.id
    ).order_by(models.ChatMessage.id.asc()).limit(30).all()

# --- Seed Sample Data Endpoint ---
@app.post("/seed", tags=["System"])
def seed_demo_data(db: Session = Depends(get_db)):
    """
    Populates realistic demo financial data:
    Income: ₹50,000
    Expenses: ₹30,000 (across Food, Shopping, Travel, Rent, Entertainment, Other)
    Savings: ₹20,000 (Savings Rate: 40%)
    Goal: New Laptop (Target: ₹80,000, Current: ₹30,000, Monthly Contribution: ₹10,000)
    """
    user = get_or_create_default_user(db)

    # Clear existing data for fresh seed
    db.query(models.Expense).filter(models.Expense.user_id == user.id).delete()
    db.query(models.Goal).filter(models.Goal.user_id == user.id).delete()
    db.query(models.Income).filter(models.Income.user_id == user.id).delete()
    db.query(models.ChatMessage).filter(models.ChatMessage.user_id == user.id).delete()
    db.commit()

    # Set Income: ₹50,000
    income = models.Income(user_id=user.id, amount=50000.0, source="Tech Software Engineer Salary")
    db.add(income)

    # Today's date reference
    today = datetime.utcnow()
    d_str = lambda offset: (today - timedelta(days=offset)).strftime("%Y-%m-%d")

    # Demo Expenses totaling exactly ₹30,000:
    # Rent: ₹12,000
    # Food: ₹6,500
    # Shopping: ₹4,500
    # Travel: ₹3,000
    # Entertainment: ₹2,500
    # Other: ₹1,500
    demo_expenses = [
        models.Expense(user_id=user.id, name="Apartment monthly rent", amount=12000.0, category="Rent", date=d_str(1)),
        models.Expense(user_id=user.id, name="Swiggy weekend feast", amount=1200.0, category="Food", date=d_str(2)),
        models.Expense(user_id=user.id, name="BigBasket organic groceries", amount=3500.0, category="Food", date=d_str(4)),
        models.Expense(user_id=user.id, name="Starbucks cold brew & snacks", amount=800.0, category="Food", date=d_str(6)),
        models.Expense(user_id=user.id, name="Zomato office lunch order", amount=1000.0, category="Food", date=d_str(8)),
        models.Expense(user_id=user.id, name="Amazon wireless earbuds purchase", amount=2500.0, category="Shopping", date=d_str(3)),
        models.Expense(user_id=user.id, name="Zara cotton casual shirt", amount=2000.0, category="Shopping", date=d_str(7)),
        models.Expense(user_id=user.id, name="Uber airport cab ride", amount=1400.0, category="Travel", date=d_str(5)),
        models.Expense(user_id=user.id, name="Petrol fuel refuel", amount=1600.0, category="Travel", date=d_str(9)),
        models.Expense(user_id=user.id, name="Netflix & Spotify monthly subscriptions", amount=1100.0, category="Entertainment", date=d_str(10)),
        models.Expense(user_id=user.id, name="BookMyShow IMAX movie passes", amount=1400.0, category="Entertainment", date=d_str(12)),
        models.Expense(user_id=user.id, name="Electricity & WiFi broadband bill", amount=1500.0, category="Other", date=d_str(14)),
    ]
    db.add_all(demo_expenses)

    # Demo Goal matching user specification:
    # Goal: New Laptop | Target: ₹80,000 | Current: ₹30,000 | Monthly contribution: ₹10,000
    demo_goal = models.Goal(
        user_id=user.id,
        name="New Laptop (M3 MacBook Air)",
        target_amount=80000.0,
        current_amount=30000.0,
        monthly_contribution=10000.0
    )
    demo_goal_2 = models.Goal(
        user_id=user.id,
        name="Emergency Cash Fund",
        target_amount=100000.0,
        current_amount=45000.0,
        monthly_contribution=5000.0
    )
    db.add_all([demo_goal, demo_goal_2])

    db.commit()
    return {"message": "Demo data successfully seeded!", "income": 50000, "expenses": 30000, "savings": 20000}
