import sys
import os

# Ensure backend directory is in python path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

print("========================================")
print("  SmartSpend AI Verification Test Suite ")
print("========================================")

# 1. Health check
print("\n[1] Testing Health Endpoint (/health)...")
res = client.get("/health")
assert res.status_code == 200, f"Health check failed: {res.status_code}"
h_data = res.json()
print("    Service:", h_data["service"])
print("    PyTorch Model Ready:", h_data["pytorch_model_ready"])
print("    FAISS RAG Index Ready:", h_data["rag_index_ready"])
print("    Status: PASS")

# 2. Seed demo data
print("\n[2] Testing Demo Seeding (/seed)...")
res = client.post("/seed")
assert res.status_code == 200, f"Seed failed: {res.status_code}"
seed_data = res.json()
print("    Message:", seed_data["message"])
print("    Status: PASS")

# 3. Dashboard metrics
print("\n[3] Testing Dashboard Metrics (/dashboard)...")
res = client.get("/dashboard")
assert res.status_code == 200, f"Dashboard failed: {res.status_code}"
d = res.json()
print(f"    Monthly Income: Rs. {d['monthly_income']:,.0f}")
print(f"    Total Expenses: Rs. {d['total_expenses']:,.0f}")
print(f"    Current Savings: Rs. {d['current_savings']:,.0f}")
print(f"    Savings Rate: {d['savings_rate']}%")
print(f"    Top Insight: {d['top_insight']['title']}")
assert d['monthly_income'] == 50000.0
assert d['total_expenses'] == 30000.0
assert d['current_savings'] == 20000.0
assert d['savings_rate'] == 40.0
print("    Status: PASS (Exact matches with prompt specifications!)")

# 4. PyTorch Categorization
print("\n[4] Testing PyTorch Model Inference (/ai/categorize)...")
test_cases = [
    ("Swiggy order", "Food"),
    ("Uber ride", "Travel"),
    ("Amazon purchase", "Shopping"),
    ("Apartment rent", "Rent"),
    ("Netflix subscription", "Entertainment"),
    ("Udemy python course", "Education"),
    ("Apollo pharmacy medicine", "Other")
]

for desc, expected in test_cases:
    res = client.post("/ai/categorize", json={"description": desc})
    assert res.status_code == 200
    cat_data = res.json()
    print(f"    Input: '{desc:25}' -> Predicted: {cat_data['category']:15} (Confidence: {cat_data['confidence_percentage']})")
    assert cat_data["category"] == expected, f"Expected {expected}, got {cat_data['category']}"
print("    Status: PASS (All test categories matched with high confidence!)")

# 5. AI Advisor: Personal Finances Route
print("\n[5] Testing AI Advisor - Personal Spending Route (/ai/chat)...")
res = client.post("/ai/chat", json={"message": "Where am I spending the most?"})
assert res.status_code == 200
chat_res = res.json()
print("    Context Type:", chat_res["context_type"])
assert "Rent" in chat_res["reply"] or "Food" in chat_res["reply"]
print("    Status: PASS")

# 6. AI Advisor: FAISS RAG Route
print("\n[6] Testing AI Advisor - FAISS RAG Route (/ai/chat)...")
res = client.post("/ai/chat", json={"message": "What is an emergency fund?"})
assert res.status_code == 200
rag_res = res.json()
print("    Context Type:", rag_res["context_type"])
print("    Sources Cited:", rag_res["sources"])
assert "emergency_fund.txt" in rag_res["sources"]
print("    Status: PASS (RAG successfully retrieved and cited emergency_fund.txt!)")

# 7. Savings Goals
print("\n[7] Testing Savings Goals (/goals)...")
res = client.get("/goals")
assert res.status_code == 200
goals = res.json()
assert len(goals) >= 1
laptop_goal = next(g for g in goals if "Laptop" in g["name"])
print(f"    Goal Name: {laptop_goal['name']}")
print(f"    Target: Rs. {laptop_goal['target_amount']:,.0f}")
print(f"    Current: Rs. {laptop_goal['current_amount']:,.0f}")
print(f"    Progress: {laptop_goal['progress_percentage']}%")
print(f"    Remaining: Rs. {laptop_goal['amount_remaining']:,.0f}")
print(f"    Estimated Time: {laptop_goal['estimated_months']} months")
assert laptop_goal["target_amount"] == 80000.0
assert laptop_goal["current_amount"] == 30000.0
assert laptop_goal["progress_percentage"] == 37.5
assert laptop_goal["amount_remaining"] == 50000.0
assert laptop_goal["estimated_months"] == 5.0
print("    Status: PASS (Goal metrics match prompt requirements 100%!)")

print("\n========================================")
print("  ALL 7 SUITE TESTS PASSED! SUCCESS!    ")
print("========================================")
