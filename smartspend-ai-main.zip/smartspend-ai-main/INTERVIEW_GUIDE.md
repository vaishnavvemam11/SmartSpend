# SmartSpend AI - Interview & Technical Architecture Guide

This guide provides concise, high-signal explanations and technical rationales for explaining SmartSpend AI during technical interviews and architecture reviews.

---

## 1. What the Project Does

**Elevator Pitch:**
> *"SmartSpend AI is an intelligent personal finance web application built with FastAPI, PyTorch, React, and FAISS. It helps users track income, manage daily expenses with AI-assisted categorization, plan savings goals with completion forecasting, and receive grounded financial education and advice through a context-aware AI assistant."*

**Core Features:**
1. **Interactive Financial Dashboard**: 4 key performance cards (Monthly Income, Total Expenses, Current Savings, Savings Rate in ₹), Recharts Category Donut Chart, and Monthly Trend Bar Chart.
2. **PyTorch Transaction Classifier**: Suggests transaction categories (Food, Shopping, Travel, Rent, Entertainment, Education, Other) with confidence scores in real-time as users type.
3. **Savings Goal Tracker**: Tracks goal milestones, remaining balances, and projected completion timelines based on monthly contributions.
4. **Basic RAG Knowledge System**: FAISS-powered vector search over curated financial education documents with direct source attribution.
5. **Context-Aware AI Advisor**: Personalized financial chat combining live SQLite financial aggregations and RAG knowledge retrieval.

---

## 2. Why PyTorch Was Used

**Interview Question:** *"Why use PyTorch for transaction categorization instead of standard keyword regex or an external cloud API?"*

**Key Talking Points:**
- **Zero Latency & Offline Capability**: External LLM/cloud APIs introduce network latency (500ms–2s), API costs, and dependency on external servers. PyTorch inference runs locally on the server in **sub-millisecond (< 2ms) CPU time**.
- **Generalization Over Rigid Rules**: Keyword regex breaks easily on variations, typos, or combined phrases (e.g., *"Swiggy weekend feast"* vs *"Swiggy"*). A trained neural model calculates learned subword n-gram weightings across feature combinations.
- **Explainable Probability Distribution**: PyTorch outputs raw logits converted via `torch.softmax()` into a calibrated probability distribution, giving users transparent confidence metrics (e.g., *"Travel - 98% confidence"*).
- **Scalability**: New categories or user-specific custom transaction labels can be fine-tuned or retrained within seconds without code refactoring.

---

## 3. How Expense Categorization Works

**Architecture:**
```
User Input: "Uber ride to office"
      │
      ▼
TfidfVectorizer (Subword & Word N-Grams: 1 to 2 grams)
      │  Vector size: V (sparse feature representation)
      ▼
PyTorch Neural Network (MLP):
  ├── Linear(V -> 64)
  ├── BatchNorm1d(64)
  ├── ReLU()
  ├── Dropout(p=0.2)
  ├── Linear(64 -> 32)
  ├── ReLU()
  └── Linear(32 -> 7 Classes)
      │
      ▼
Softmax Activation: probs = torch.softmax(logits, dim=1)
      │
      ▼
Prediction: Category = "Travel", Confidence = 99%
```

**Workflow:**
1. **Feature Extraction**: Text is lowercased and vectorized using character/word n-grams via TF-IDF to capture prefixes, vendor names, and intent keywords.
2. **Forward Pass**: The vector passes through fully connected layers with Batch Normalization and Dropout to prevent overfitting.
3. **Softmax Output**: Softmax produces a probability distribution summing to 1.0 across the 7 target categories:
   - Food, Shopping, Travel, Rent, Entertainment, Education, Other.
4. **Confidence Badge**: The UI receives the category and confidence percentage to display a live badge as the user types.

---

## 4. What RAG Is and How It Is Implemented

**Interview Question:** *"What is RAG and why is it useful in personal finance?"*

**Explanation:**
- **RAG (Retrieval-Augmented Generation)** is an AI technique that combines information retrieval with query synthesis. Instead of hallucinating answers or relying on static knowledge, the system retrieves verified document chunks and grounds its answers directly on that context.
- **In SmartSpend AI**:
  - **Knowledge Documents**: 5 focused financial knowledge files (`budgeting.txt`, `saving.txt`, `emergency_fund.txt`, `compound_interest.txt`, `debt_management.txt`).
  - **Chunking**: Markdown/text files are split into topical sections based on headers (`## `).
  - **Embeddings & Vector Store**: Chunks are transformed into normalized vector embeddings and indexed in **FAISS (Facebook AI Similarity Search)** using `faiss.IndexFlatIP` (Cosine Similarity).
  - **Retrieval**: When a user asks *"What is an emergency fund?"*, FAISS searches for nearest neighbors in vector space in < 1ms, retrieves the top matching chunks, and generates a structured answer citing `Source: emergency_fund.txt`.

---

## 5. How the AI Advisor Works

**Dynamic Query Routing:**
When the user sends a message to `/ai/chat`, the endpoint intelligently routes the query:

1. **User Financial Context Route**:
   - If the user asks *"Where am I spending the most?"*, *"How can I reduce expenses?"*, or *"How much can I save?"*:
   - The backend queries SQLite for live user data (monthly income, category spending totals, savings rate, and goal progress).
   - Generates transparent, math-grounded answers citing the user's real numbers (e.g., *"Food is your highest spending at ₹6,500 (21.7% of total expenses)"*).

2. **Educational Knowledge Route (RAG)**:
   - If the user asks about financial concepts (*"What is the 50/30/20 rule?"*, *"Explain compound interest"*):
   - Query is routed to the FAISS RAG engine to retrieve verified concepts and cite source files.

3. **Hybrid / Goal Horizon Route**:
   - Analyzes progress toward user goals (e.g., *"New Laptop"* target vs current savings) and calculates exact acceleration strategies.

---

## 6. How the Frontend Communicates with FastAPI

- **RESTful API**: Standard HTTP REST communication using Axios with JSON payloads.
- **CORS Handling**: FastAPI configured with `CORSMiddleware` to allow communication from `http://localhost:5173` (Vite dev) and `http://localhost:3000` (Docker production).
- **Key Endpoints**:
  - `GET /dashboard`: Aggregated dashboard metrics, charts, and top insights.
  - `POST /ai/categorize`: Real-time PyTorch inference for the expense modal.
  - `GET /expenses`, `POST /expenses`, `PUT /expenses/{id}`, `DELETE /expenses/{id}`: CRUD operations.
  - `GET /goals`, `POST /goals`, `POST /goals/{id}/contribute`: Savings goals.
  - `POST /ai/chat`: Advisor conversational endpoint.
  - `POST /seed`: One-click realistic demo data population for fast interview demonstration.

---

## 7. How Docker Is Used

- **Multi-Stage Frontend Build**:
  - Stage 1: Node 20/22 image builds optimized static assets with `npm run build`.
  - Stage 2: Ultra-lightweight `nginx:alpine` image serves static assets on port 80.
- **Backend Container**:
  - Python 3.12-slim base image installs PyTorch CPU and FAISS dependencies.
  - Runs Uvicorn ASGI server on port 8000.
- **Docker Compose Orchestration**:
  - Single command startup: `docker compose up --build`.
  - Binds frontend port 3000 and backend port 8000.
  - Persists database data across container restarts using named volumes.
