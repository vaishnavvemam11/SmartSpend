import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const getHealth = async () => (await api.get('/health')).data;

export const getDashboard = async () => (await api.get('/dashboard')).data;

export const getIncome = async () => (await api.get('/income')).data;
export const updateIncome = async (amount, source = 'Primary Salary') =>
  (await api.post('/income', { amount, source })).data;

export const getExpenses = async (category = null) => {
  const params = category && category !== 'All' ? { category } : {};
  return (await api.get('/expenses', { params })).data;
};
export const createExpense = async (data) => (await api.post('/expenses', data)).data;
export const updateExpense = async (id, data) => (await api.put(`/expenses/${id}`, data)).data;
export const deleteExpense = async (id) => (await api.delete(`/expenses/${id}`)).data;

export const getGoals = async () => (await api.get('/goals')).data;
export const createGoal = async (data) => (await api.post('/goals', data)).data;
export const updateGoal = async (id, data) => (await api.put(`/goals/${id}`, data)).data;
export const contributeToGoal = async (id, amount) =>
  (await api.post(`/goals/${id}/contribute`, { amount })).data;
export const deleteGoal = async (id) => (await api.delete(`/goals/${id}`)).data;

export const predictCategory = async (description) =>
  (await api.post('/ai/categorize', { description })).data;

export const getInsights = async () => (await api.get('/ai/insights')).data;

export const sendChatMessage = async (message) =>
  (await api.post('/ai/chat', { message })).data;
export const getChatHistory = async () => (await api.get('/ai/chat/history')).data;

export const seedDemoData = async () => (await api.post('/seed')).data;

export default api;
