import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import ExpenseModal from './components/ExpenseModal';
import GoalModal from './components/GoalModal';
import Dashboard from './pages/Dashboard';
import Expenses from './pages/Expenses';
import Goals from './pages/Goals';
import Advisor from './pages/Advisor';
import Settings from './pages/Settings';

import {
  getHealth,
  getDashboard,
  getExpenses,
  getGoals,
  createExpense,
  updateExpense,
  deleteExpense,
  createGoal,
  updateGoal,
  deleteGoal,
  contributeToGoal,
  seedDemoData
} from './api';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem('smartspend_theme') === 'dark' ||
      (!('smartspend_theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches);
  });
  const [mobileOpen, setMobileOpen] = useState(false);
  const [apiOnline, setApiOnline] = useState(false);

  // App Data State
  const [dashboardData, setDashboardData] = useState(null);
  const [expenses, setExpenses] = useState([]);
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isSeeding, setIsSeeding] = useState(false);

  // Modals
  const [expenseModalOpen, setExpenseModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState(null);
  const [goalModalOpen, setGoalModalOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState(null);

  // Notification Toast
  const [toast, setToast] = useState(null);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  // Sync Dark Mode class with HTML root
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('smartspend_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('smartspend_theme', 'light');
    }
  }, [darkMode]);

  // Initial load
  useEffect(() => {
    checkHealthAndLoad();
  }, []);

  const checkHealthAndLoad = async () => {
    try {
      setLoading(true);
      await getHealth();
      setApiOnline(true);
      await refreshAllData();
    } catch (err) {
      console.error('API connection check failed:', err);
      setApiOnline(false);
    } finally {
      setLoading(false);
    }
  };

  const refreshAllData = async () => {
    try {
      const [dash, exp, gls] = await Promise.all([
        getDashboard(),
        getExpenses(),
        getGoals()
      ]);
      setDashboardData(dash);
      setExpenses(exp);
      setGoals(gls);
      setApiOnline(true);
    } catch (err) {
      console.error('Failed refreshing data:', err);
    }
  };

  const handleSeedData = async () => {
    try {
      setIsSeeding(true);
      await seedDemoData();
      await refreshAllData();
      showToast('Demo data seeded! ₹50,000 income, ₹30,000 expenses, ₹20,000 savings.');
    } catch (err) {
      console.error('Seeding error:', err);
      showToast('Failed to seed demo data', 'error');
    } finally {
      setIsSeeding(false);
    }
  };

  // Expense Handlers
  const handleSaveExpense = async (data) => {
    try {
      if (editingExpense) {
        await updateExpense(editingExpense.id, data);
        showToast('Expense updated successfully!');
      } else {
        await createExpense(data);
        showToast('Expense added successfully!');
      }
      setExpenseModalOpen(false);
      setEditingExpense(null);
      await refreshAllData();
    } catch (err) {
      console.error('Save expense error:', err);
      showToast('Failed to save expense', 'error');
    }
  };

  const handleDeleteExpense = async (id) => {
    if (!window.confirm('Are you sure you want to delete this expense?')) return;
    try {
      await deleteExpense(id);
      showToast('Expense deleted');
      await refreshAllData();
    } catch (err) {
      console.error('Delete expense error:', err);
      showToast('Failed to delete expense', 'error');
    }
  };

  // Goal Handlers
  const handleSaveGoal = async (data) => {
    try {
      if (editingGoal) {
        await updateGoal(editingGoal.id, data);
        showToast('Goal updated successfully!');
      } else {
        await createGoal(data);
        showToast('Savings goal created!');
      }
      setGoalModalOpen(false);
      setEditingGoal(null);
      await refreshAllData();
    } catch (err) {
      console.error('Save goal error:', err);
      showToast('Failed to save goal', 'error');
    }
  };

  const handleDeleteGoal = async (id) => {
    if (!window.confirm('Are you sure you want to delete this goal?')) return;
    try {
      await deleteGoal(id);
      showToast('Savings goal deleted');
      await refreshAllData();
    } catch (err) {
      console.error('Delete goal error:', err);
      showToast('Failed to delete goal', 'error');
    }
  };

  const handleContributeGoal = async (id, amount) => {
    try {
      await contributeToGoal(id, amount);
      showToast(`Deposited ₹${amount.toLocaleString('en-IN')} to goal! 🎉`);
      await refreshAllData();
    } catch (err) {
      console.error('Contribute error:', err);
      showToast('Failed to contribute to goal', 'error');
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-950 overflow-hidden font-sans text-slate-900 dark:text-slate-100">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-3 duration-300">
          <div
            className={`px-4 py-3 rounded-2xl shadow-xl border text-xs font-semibold flex items-center gap-2 ${
              toast.type === 'error'
                ? 'bg-rose-500 text-white border-rose-600'
                : 'bg-emerald-600 text-white border-emerald-700'
            }`}
          >
            <span>{toast.message}</span>
          </div>
        </div>
      )}

      {/* Navigation Sidebar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        mobileOpen={mobileOpen}
        setMobileOpen={setMobileOpen}
        apiOnline={apiOnline}
      />

      {/* Main Workspace Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header
          activeTab={activeTab}
          onOpenAddExpense={() => {
            setEditingExpense(null);
            setExpenseModalOpen(true);
          }}
          onSeedData={handleSeedData}
          isSeeding={isSeeding}
          setMobileOpen={setMobileOpen}
        />

        <main className="flex-1 overflow-y-auto">
          {activeTab === 'dashboard' && (
            <Dashboard
              dashboardData={dashboardData}
              loading={loading}
              onOpenAddExpense={() => {
                setEditingExpense(null);
                setExpenseModalOpen(true);
              }}
              onOpenGoalModal={() => {
                setEditingGoal(null);
                setGoalModalOpen(true);
              }}
            />
          )}

          {activeTab === 'expenses' && (
            <Expenses
              expenses={expenses}
              loading={loading}
              onOpenAdd={() => {
                setEditingExpense(null);
                setExpenseModalOpen(true);
              }}
              onOpenEdit={(item) => {
                setEditingExpense(item);
                setExpenseModalOpen(true);
              }}
              onDelete={handleDeleteExpense}
            />
          )}

          {activeTab === 'goals' && (
            <Goals
              goals={goals}
              loading={loading}
              onOpenAdd={() => {
                setEditingGoal(null);
                setGoalModalOpen(true);
              }}
              onOpenEdit={(g) => {
                setEditingGoal(g);
                setGoalModalOpen(true);
              }}
              onDelete={handleDeleteGoal}
              onContribute={handleContributeGoal}
            />
          )}

          {activeTab === 'advisor' && <Advisor />}

          {activeTab === 'settings' && (
            <Settings
              currentIncome={dashboardData?.monthly_income || 50000}
              onIncomeUpdated={refreshAllData}
              darkMode={darkMode}
              setDarkMode={setDarkMode}
              onSeedData={handleSeedData}
              isSeeding={isSeeding}
              apiOnline={apiOnline}
            />
          )}
        </main>
      </div>

      {/* Modals */}
      <ExpenseModal
        isOpen={expenseModalOpen}
        onClose={() => {
          setExpenseModalOpen(false);
          setEditingExpense(null);
        }}
        onSave={handleSaveExpense}
        initialData={editingExpense}
      />

      <GoalModal
        isOpen={goalModalOpen}
        onClose={() => {
          setGoalModalOpen(false);
          setEditingGoal(null);
        }}
        onSave={handleSaveGoal}
        initialData={editingGoal}
      />
    </div>
  );
}
