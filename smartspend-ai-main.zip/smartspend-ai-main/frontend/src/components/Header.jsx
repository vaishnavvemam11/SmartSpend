import React from 'react';
import { Menu, Plus, RefreshCw, Sparkles } from 'lucide-react';

export default function Header({
  activeTab,
  onOpenAddExpense,
  onSeedData,
  isSeeding,
  setMobileOpen
}) {
  const titles = {
    dashboard: {
      title: 'Financial Dashboard',
      subtitle: 'Real-time overview of income, expenses, and savings',
    },
    expenses: {
      title: 'Expense Management',
      subtitle: 'Track and categorize transactions with PyTorch AI',
    },
    goals: {
      title: 'Savings Goals',
      subtitle: 'Target milestones with automated timeline projections',
    },
    advisor: {
      title: 'AI Financial Advisor',
      subtitle: 'Personalized budget insights & FAISS-powered educational RAG',
    },
    settings: {
      title: 'Application Settings',
      subtitle: 'Manage monthly income, system configuration, and data',
    },
  };

  const current = titles[activeTab] || titles.dashboard;

  return (
    <header className="h-20 border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md sticky top-0 z-30 px-6 flex items-center justify-between">
      <div className="flex items-center gap-4">
        <button
          onClick={() => setMobileOpen(true)}
          className="lg:hidden p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <Menu className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">
            {current.title}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 hidden sm:block">
            {current.subtitle}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Seed Demo Data Button */}
        <button
          onClick={onSeedData}
          disabled={isSeeding}
          title="Seed realistic demo data (₹50,000 Income, ₹30,000 Expenses, ₹20,000 Savings)"
          className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-emerald-600 ${isSeeding ? 'animate-spin' : ''}`} />
          <span className="hidden md:inline">Seed Demo Data</span>
          <span className="md:hidden">Demo</span>
        </button>

        {/* Add Expense Button */}
        <button
          onClick={onOpenAddExpense}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white shadow-md shadow-emerald-500/20 transition-all transform active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>Add Expense</span>
        </button>
      </div>
    </header>
  );
}
