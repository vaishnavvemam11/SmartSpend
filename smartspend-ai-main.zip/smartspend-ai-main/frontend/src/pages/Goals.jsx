import React, { useState } from 'react';
import {
  Target,
  Plus,
  Edit2,
  Trash2,
  Clock,
  CheckCircle2,
  PiggyBank,
  ArrowUpRight,
  TrendingUp
} from 'lucide-react';

export default function Goals({
  goals,
  loading,
  onOpenAdd,
  onOpenEdit,
  onDelete,
  onContribute
}) {
  const [contributeGoal, setContributeGoal] = useState(null);
  const [contributeAmount, setContributeAmount] = useState('5000');

  const handleContributeSubmit = (e) => {
    e.preventDefault();
    if (!contributeGoal || Number(contributeAmount) <= 0) return;
    onContribute(contributeGoal.id, parseFloat(contributeAmount));
    setContributeGoal(null);
  };

  return (
    <div className="p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            Your Financial Milestones
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Automated timeline projections based on your monthly savings velocity
          </p>
        </div>
        <button
          onClick={onOpenAdd}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white shadow-md shadow-emerald-500/20 transition-all active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>New Savings Goal</span>
        </button>
      </div>

      {/* Goals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {goals.map((goal) => {
          const progress = goal.progress_percentage || 0;
          const isComplete = progress >= 100;

          return (
            <div
              key={goal.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                {/* Card Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
                      <Target className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                        {goal.name}
                      </h3>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                        Target: ₹{Number(goal.target_amount).toLocaleString('en-IN')}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => onOpenEdit(goal)}
                      title="Edit Goal"
                      className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onDelete(goal.id)}
                      title="Delete Goal"
                      className="p-1.5 rounded-lg text-rose-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Progress Bar & Percentage */}
                <div className="space-y-1.5 mb-5">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className="text-slate-500 dark:text-slate-400">Progress</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-mono">
                      {progress}%
                    </span>
                  </div>
                  <div className="w-full h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden p-0.5">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        isComplete
                          ? 'bg-emerald-500'
                          : 'bg-gradient-to-r from-emerald-500 to-teal-500'
                      }`}
                      style={{ width: `${Math.min(100, progress)}%` }}
                    />
                  </div>
                </div>

                {/* Key Metrics Grid */}
                <div className="grid grid-cols-2 gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-800 text-xs mb-5">
                  <div>
                    <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">
                      Current Saved
                    </span>
                    <p className="font-bold text-slate-900 dark:text-white font-mono text-sm mt-0.5">
                      ₹{Number(goal.current_amount).toLocaleString('en-IN')}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">
                      Remaining
                    </span>
                    <p className="font-bold text-rose-600 dark:text-rose-400 font-mono text-sm mt-0.5">
                      ₹{Number(goal.amount_remaining).toLocaleString('en-IN')}
                    </p>
                  </div>
                  <div className="col-span-2 pt-1 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-slate-500 dark:text-slate-400">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      Estimated Time:
                    </span>
                    <span className="font-bold text-slate-800 dark:text-slate-200 font-mono">
                      {isComplete ? 'Goal Achieved! 🎉' : `${goal.estimated_months} months`}
                    </span>
                  </div>
                </div>
              </div>

              {/* Contribute Action */}
              <button
                onClick={() => setContributeGoal(goal)}
                className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-emerald-500 dark:hover:border-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 text-slate-700 dark:text-slate-200 hover:text-emerald-700 dark:hover:text-emerald-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
              >
                <PiggyBank className="w-4 h-4 text-emerald-600" />
                <span>+ Contribute Funds</span>
              </button>
            </div>
          );
        })}

        {goals.length === 0 && (
          <div className="col-span-full py-16 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
            <Target className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300">
              No savings goals yet
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mt-1 mb-4">
              Set your first target (like a New Laptop or Emergency Fund) to track milestones and time horizons.
            </p>
            <button
              onClick={onOpenAdd}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm"
            >
              Create Goal
            </button>
          </div>
        )}
      </div>

      {/* Quick Deposit / Contribute Modal */}
      {contributeGoal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-2xl">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-1">
              Contribute to {contributeGoal.name}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Deposit additional funds to accelerate your timeline.
            </p>

            <form onSubmit={handleContributeSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wider mb-1.5">
                  Deposit Amount (₹)
                </label>
                <input
                  type="number"
                  required
                  step="1"
                  value={contributeAmount}
                  onChange={(e) => setContributeAmount(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setContributeGoal(null)}
                  className="px-4 py-2 text-xs font-semibold rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm"
                >
                  Confirm Deposit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
