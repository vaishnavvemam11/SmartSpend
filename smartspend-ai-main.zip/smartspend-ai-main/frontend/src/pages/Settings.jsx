import React, { useState } from 'react';
import {
  Settings as SettingsIcon,
  DollarSign,
  Moon,
  Sun,
  Database,
  Cpu,
  RefreshCw,
  CheckCircle2,
  FileText
} from 'lucide-react';
import { updateIncome } from '../api';

export default function Settings({
  currentIncome,
  onIncomeUpdated,
  darkMode,
  setDarkMode,
  onSeedData,
  isSeeding,
  apiOnline
}) {
  const [incomeInput, setIncomeInput] = useState(String(currentIncome || 50000));
  const [savingIncome, setSavingIncome] = useState(false);
  const [incomeSuccess, setIncomeSuccess] = useState(false);

  const handleIncomeSubmit = async (e) => {
    e.preventDefault();
    const val = parseFloat(incomeInput);
    if (!val || val <= 0) return;

    try {
      setSavingIncome(true);
      await updateIncome(val, 'Primary Salary');
      setIncomeSuccess(true);
      onIncomeUpdated();
      setTimeout(() => setIncomeSuccess(false), 3000);
    } catch (err) {
      console.error('Error saving income:', err);
    } finally {
      setSavingIncome(false);
    }
  };

  return (
    <div className="p-6 lg:p-8 space-y-6 max-w-4xl mx-auto">
      <div>
        <h2 className="text-lg font-bold text-slate-900 dark:text-white">
          System & Financial Preferences
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Configure baseline income, appearance themes, and inspect AI runtime components
        </p>
      </div>

      {/* Monthly Income Setting */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Baseline Monthly Income
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Used to calculate savings rate, budget allocations, and goal feasibility
            </p>
          </div>
        </div>

        <form onSubmit={handleIncomeSubmit} className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 max-w-md">
          <div className="relative flex-1">
            <span className="absolute left-3.5 top-2.5 text-slate-400 text-sm font-bold">₹</span>
            <input
              type="number"
              step="100"
              required
              value={incomeInput}
              onChange={(e) => setIncomeInput(e.target.value)}
              className="w-full pl-8 pr-4 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono font-bold"
            />
          </div>
          <button
            type="submit"
            disabled={savingIncome}
            className="px-5 py-2 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm transition-all disabled:opacity-50 flex items-center justify-center gap-1.5"
          >
            {incomeSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-200" />
                <span>Saved!</span>
              </>
            ) : (
              <span>Update Income</span>
            )}
          </button>
        </form>
      </div>

      {/* Appearance & Theme */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
              {darkMode ? <Moon className="w-5 h-5 text-amber-400" /> : <Sun className="w-5 h-5 text-amber-500" />}
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Interface Theme
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Switch between high-contrast Dark Mode and clean Light Mode
              </p>
            </div>
          </div>

          <button
            onClick={() => setDarkMode(!darkMode)}
            className="px-4 py-2 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
          >
            {darkMode ? 'Switch to Light' : 'Switch to Dark'}
          </button>
        </div>
      </div>

      {/* Demo Seeding */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Reset or Seed Interview Demo Data
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Populates ₹50,000 Income, ₹30,000 Expenses, ₹20,000 Savings (40%), and New Laptop Goal
              </p>
            </div>
          </div>

          <button
            onClick={onSeedData}
            disabled={isSeeding}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-900 text-white dark:bg-white dark:text-slate-900 hover:opacity-90 shadow-sm transition-all disabled:opacity-50 flex items-center gap-2"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSeeding ? 'animate-spin' : ''}`} />
            <span>{isSeeding ? 'Populating...' : 'Seed Data Now'}</span>
          </button>
        </div>
      </div>

      {/* AI & System Runtime Diagnostics */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              AI Runtime Architecture Diagnostics
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Technical components powering SmartSpend AI
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/60 space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              PyTorch Categorization Model
            </span>
            <p className="font-semibold text-slate-800 dark:text-slate-200">
              ExpenseClassifier MLP (Subword TF-IDF + BatchNorm + Softmax)
            </p>
            <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-mono">
              Status: Active • Sub-millisecond CPU Inference
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/60 space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Financial RAG Vector Store
            </span>
            <p className="font-semibold text-slate-800 dark:text-slate-200">
              FAISS IndexFlatIP (Cosine Similarity)
            </p>
            <p className="text-[11px] text-teal-600 dark:text-teal-400 font-mono">
              5 Knowledge Documents Indexed
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/60 space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Relational Storage
            </span>
            <p className="font-semibold text-slate-800 dark:text-slate-200">
              SQLite (smartspend.db via SQLAlchemy)
            </p>
            <p className="text-[11px] text-slate-500 font-mono">
              Users, Income, Expenses, Goals, ChatHistory
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/60 space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              API Server
            </span>
            <p className="font-semibold text-slate-800 dark:text-slate-200">
              FastAPI + Uvicorn ASGI Server
            </p>
            <p className="text-[11px] text-slate-500 font-mono">
              Connection: {apiOnline ? 'Connected (Port 8000)' : 'Reconnecting...'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
