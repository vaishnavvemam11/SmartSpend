import React from 'react';
import {
  TrendingUp,
  CreditCard,
  PiggyBank,
  Percent,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle2,
  Calendar
} from 'lucide-react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid
} from 'recharts';
import StatCard from '../components/StatCard';

const CATEGORY_COLORS = {
  Food: '#10b981',        // Emerald
  Shopping: '#ec4899',    // Pink
  Travel: '#3b82f6',      // Blue
  Rent: '#8b5cf6',        // Purple
  Entertainment: '#f59e0b',// Amber
  Education: '#06b6d4',   // Cyan
  Other: '#64748b',       // Slate
};

export default function Dashboard({
  dashboardData,
  loading,
  onOpenAddExpense,
  onOpenGoalModal
}) {
  if (loading || !dashboardData) {
    return (
      <div className="p-8 flex items-center justify-center min-h-[400px]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">Loading SmartSpend metrics...</p>
        </div>
      </div>
    );
  }

  const {
    monthly_income,
    total_expenses,
    current_savings,
    savings_rate,
    spending_overview,
    monthly_overview,
    top_insight,
    recent_expenses
  } = dashboardData;

  // Filter spending categories with amount > 0 for pie chart
  const pieData = spending_overview.filter((item) => item.amount > 0);

  const customTooltipFormatter = (value) => [`₹${Number(value).toLocaleString('en-IN')}`, ''];

  return (
    <div className="p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* 4 Main Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Monthly Income"
          value={monthly_income}
          subtext="Net monthly earnings"
          icon={TrendingUp}
          color="emerald"
        />
        <StatCard
          title="Total Expenses"
          value={total_expenses}
          subtext="Tracked this month"
          icon={CreditCard}
          color="rose"
        />
        <StatCard
          title="Current Savings"
          value={current_savings}
          subtext="Available surplus"
          icon={PiggyBank}
          color="indigo"
        />
        <StatCard
          title="Savings Percentage"
          value={savings_rate}
          isPercentage={true}
          subtext={savings_rate >= 20 ? 'Exceeds 20% benchmark' : 'Below 20% target'}
          icon={Percent}
          color={savings_rate >= 20 ? 'emerald' : 'amber'}
        />
      </div>

      {/* AI Insight Spotlight Card */}
      {top_insight && (
        <div className="relative overflow-hidden rounded-2xl p-5 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 text-white shadow-lg shadow-emerald-600/10">
          <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="p-2.5 rounded-xl bg-white/20 backdrop-blur-md">
                <Sparkles className="w-5 h-5 text-yellow-300" />
              </div>
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-emerald-100">
                  AI Financial Spotlight
                </span>
                <h4 className="text-sm md:text-base font-bold text-white mt-0.5">
                  {top_insight.title}: {top_insight.message}
                </h4>
              </div>
            </div>
            {top_insight.metric && (
              <span className="px-3 py-1.5 rounded-xl bg-white/20 backdrop-blur-md text-xs font-bold tracking-wide text-white flex-shrink-0">
                {top_insight.metric}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Visual Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Spending Overview Donut Chart */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Spending Overview
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Expense distribution by category
              </p>
            </div>
            <button
              onClick={onOpenAddExpense}
              className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline"
            >
              + Add
            </button>
          </div>

          <div className="h-64 w-full flex-1 flex items-center justify-center">
            {pieData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={58}
                    outerRadius={85}
                    paddingAngle={4}
                    dataKey="amount"
                    nameKey="category"
                  >
                    {pieData.map((entry) => (
                      <Cell
                        key={`cell-${entry.category}`}
                        fill={CATEGORY_COLORS[entry.category] || '#64748b'}
                      />
                    ))}
                  </Pie>
                  <Tooltip formatter={customTooltipFormatter} />
                  <Legend
                    verticalAlign="bottom"
                    iconType="circle"
                    formatter={(val) => <span className="text-xs text-slate-600 dark:text-slate-400">{val}</span>}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center text-slate-400 text-xs">
                No expense transactions recorded yet.
              </div>
            )}
          </div>
        </div>

        {/* Monthly Overview Bar Chart */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Monthly Overview
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Income vs Expenses vs Net Savings
              </p>
            </div>
          </div>

          <div className="h-64 w-full flex-1">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthly_overview} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `₹${v / 1000}k`} />
                <Tooltip formatter={customTooltipFormatter} />
                <Legend
                  verticalAlign="top"
                  align="right"
                  iconType="circle"
                  formatter={(val) => <span className="text-xs capitalize text-slate-600 dark:text-slate-400">{val}</span>}
                />
                <Bar dataKey="income" name="Income" fill="#10b981" radius={[4, 4, 0, 0]} />
                <Bar dataKey="expenses" name="Expenses" fill="#f43f5e" radius={[4, 4, 0, 0]} />
                <Bar dataKey="savings" name="Savings" fill="#6366f1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Recent Expenses List */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Recent Transactions
          </h3>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Latest 5 entries
          </span>
        </div>

        {recent_expenses && recent_expenses.length > 0 ? (
          <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
            {recent_expenses.map((item) => (
              <div key={item.id} className="py-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: CATEGORY_COLORS[item.category] || '#64748b' }}
                  />
                  <div>
                    <p className="text-xs font-semibold text-slate-900 dark:text-white">
                      {item.name}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      {item.category} • {item.date}
                    </p>
                  </div>
                </div>
                <span className="text-xs font-bold text-slate-900 dark:text-white font-mono">
                  -₹{Number(item.amount).toLocaleString('en-IN')}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-slate-400 py-4 text-center">No recent expenses.</p>
        )}
      </div>
    </div>
  );
}
