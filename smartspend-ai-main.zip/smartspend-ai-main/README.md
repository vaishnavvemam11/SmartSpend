# 🌟 SmartSpend AI - Intelligent Personal Finance Assistant

SmartSpend AI is a modern, lightweight, AI-powered personal finance assistant designed to help users track income and expenses, understand spending habits, plan savings goals with timeline forecasting, and receive context-grounded financial advice through a native PyTorch transaction classifier and a FAISS-based RAG system.

---

## 🎯 Problem It Solves

Traditional personal finance spreadsheets and basic CRUD budgeting apps are manual, tedious, and disconnected from financial education:
1. **Manual Categorization Friction**: Users frequently abandon budgeting tools because manually categorizing every coffee or cab ride is repetitive.
2. **Lack of Transparent Goal Projections**: Users know *what* they want to buy, but lack clear calculation models showing *when* they can afford it.
3. **Disconnected Financial Advice**: Traditional educational articles are generic and don't take the user's live financial data into account.

SmartSpend AI solves this by combining **real-time PyTorch inference**, **transparent statistical insights**, **interactive Recharts visualizations**, and a **FAISS knowledge base** in an intuitive fintech interface.

---

## ✨ Features

- **📊 Comprehensive Financial Dashboard**:
  - 4 Key metric cards: Monthly Income, Total Expenses, Current Savings, and Savings Rate (in `₹`).
  - Interactive Recharts Donut Chart breaking down expenses across 7 categories: Food, Shopping, Travel, Rent, Entertainment, Education, and Other.
  - Monthly Overview Bar Chart tracking Income vs Expenses vs Net Savings.
  - Dynamic AI Spotlight banner highlighting key spending alerts.
- **⚡ PyTorch-Powered Expense Management**:
  - Live category suggestion with calibrated percentage confidence as the user types (e.g., *"Swiggy order"* $\rightarrow$ Food `99%`, *"Uber ride"* $\rightarrow$ Travel `99%`, *"Amazon purchase"* $\rightarrow$ Shopping `99%`).
  - Complete CRUD table with category filtering and real-time search.
- **🎯 Milestone-Based Savings Goals**:
  - Goal progress tracking (`%` achieved, `₹` balance remaining).
  - Dynamic completion horizon calculation based on monthly contribution rate.
  - Quick "+ Contribute" deposit modal to accelerate timelines.
- **🤖 Context-Aware AI Advisor & RAG**:
  - Answers personal financial questions using live SQLite aggregations (*"Where am I spending the most?"*, *"How can I reduce expenses?"*).
  - Answers financial literacy questions using **FAISS RAG** (*"What is an emergency fund?"*, *"Explain the 50/30/20 rule"*), displaying exact source citations.
- **🌓 Modern Fintech UI**:
  - Dark Mode and Light Mode with persistence.
  - Clean sidebar navigation, responsive mobile drawer, and Lucide React icons.
- **🧪 One-Click Demo Seeding**:
  - Instantly populates the system with ₹50,000 income, ₹30,000 expenses, ₹20,000 savings (40%), and a ₹80,000 New Laptop goal for fast demonstration.

---

## 🛠 Technology Stack

| Layer | Technologies |
|---|---|
| **Backend** | Python 3.12, FastAPI, Uvicorn, Pydantic v2, SQLAlchemy |
| **AI & ML** | PyTorch (Neural MLP Classifier), Scikit-Learn (TF-IDF vectorizer) |
| **RAG** | FAISS CPU (`IndexFlatIP`), Curated Markdown/Text Knowledge Base |
| **Frontend** | React 19, Vite, Tailwind CSS, Recharts, Lucide React, Axios |
| **Storage** | SQLite (`smartspend.db`) |
| **DevOps** | Docker, Docker Compose, Nginx Multi-Stage Build |

---

## 🧠 AI Functionality

### 1. PyTorch Transaction Categorization (`backend/ai.py`)
- **Neural Architecture**: 2-layer Multi-Layer Perceptron (MLP) with Batch Normalization, ReLU activation, Dropout ($p=0.2$), and Linear output layers.
- **Input Features**: Character & subword n-grams (1–2 grams) extracted with TF-IDF over transaction descriptions.
- **Inference**: Sub-millisecond CPU forward pass with `torch.softmax()` producing calibrated probability confidence.
- **Explainability**: No black-box remote APIs. Self-contained, offline-capable, and easily retrainable.

### 2. Basic RAG with FAISS (`backend/rag.py`)
- **Knowledge Base Documents**:
  - `knowledge_base/budgeting.txt`: 50/30/20 rule, zero-based budgeting, envelope systems.
  - `knowledge_base/saving.txt`: Paying yourself first, sinking funds, automation.
  - `knowledge_base/emergency_fund.txt`: 3–6 months expense rules, liquidity vs yield.
  - `knowledge_base/compound_interest.txt`: Mathematical formula, Rule of 72, time horizon.
  - `knowledge_base/debt_management.txt`: Avalanche vs Snowball methods, good vs bad debt.
- **Vector Search**: Chunks are embedded and indexed into `faiss.IndexFlatIP` (Cosine Similarity). When a user asks an educational question, the top matching chunks are retrieved and displayed with source badges.

---

## 🏗 Architecture Overview

```
                           ┌────────────────────────┐
                           │      React + Vite      │
                           │  Tailwind CSS + Recharts│
                           │    (Port 3000/5173)    │
                           └───────────┬────────────┘
                                       │ HTTP / REST
                                       ▼
                           ┌────────────────────────┐
                           │   FastAPI ASGI Server  │
                           │      (Port 8000)       │
                           └───┬───────┬────────┬───┘
                               │       │        │
            ┌──────────────────┘       │        └──────────────────┐
            ▼                          ▼                           ▼
┌───────────────────────┐  ┌──────────────────────┐  ┌────────────────────────┐
│ PyTorch Categorizer   │  │   FAISS Vector RAG   │  │    SQLite Database     │
│ (MLP + Softmax Probs) │  │  (Knowledge Base)    │  │   (Income, Expenses,   │
│ Sub-millisecond < 2ms │  │  IndexFlatIP Search  │  │     Goals, History)    │
└───────────────────────┘  └──────────────────────┘  └────────────────────────┘
```

---

## 🚀 Quickstart & Local Installation

### Prerequisites
- Python 3.10+
- Node.js 18+ and npm

### 1. Run the Backend
```bash
cd smartspend-ai/backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```
Backend will be live at `http://localhost:8000`.
API documentation is accessible at `http://localhost:8000/docs`.

### 2. Run the Frontend
```bash
cd smartspend-ai/frontend
npm install
npm run dev
```
Frontend will be live at `http://localhost:5173`.

---

## 🐳 Docker Deployment

To launch the complete application with Docker Compose:

```bash
docker compose up --build
```

- **Frontend**: Accessible at `http://localhost:3000`
- **Backend API**: Accessible at `http://localhost:8000`
- **Interactive Swagger Docs**: Accessible at `http://localhost:8000/docs`

To stop the containers:
```bash
docker compose down
```

---

## 📈 Future Improvements

1. **Bank Statement CSV/PDF Ingestion**: Bulk parse transaction statements and categorize in batches.
2. **Recurring Bill Forecasts**: Detect monthly subscription patterns and alert upcoming dues.
3. **Fine-Tuned Embeddings**: Expand the financial knowledge base with tax optimization strategies (Section 80C, PPF, NPS).
4. **Multi-Currency Support**: Expand beyond INR (`₹`) to USD (`$`), EUR (`€`), and GBP (`£`).

---

## 📚 Interview Guide

For detailed technical talking points on PyTorch design choices, RAG architecture, FastAPI routing, and interview answers, refer to [**`INTERVIEW_GUIDE.md`**](./INTERVIEW_GUIDE.md).
